#!/bin/sh
echo "Enter length:"
read length
echo "Enter breadth:"
read breadth
echo "Enter radius:"
read radius
echo "Area of rectangle is :"
echo "$breadth * $length" | bc -l
echo "Perimeter of rectangle is :"
echo "2 * ($breadth + $length)" | bc -l
echo "Perimeter of circle is :"
echo "2 * $radius * 3.14" | bc -l
echo "area of circle is :"
echo "3.14 * ($radius * $radius)" | bc -l