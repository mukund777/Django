#!/bin/bash
echo $#