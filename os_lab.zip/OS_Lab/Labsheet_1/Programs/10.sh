#!/bin/bash
N=1
echo Enter new dir:
read nn
mkdir $nn
echo Enter number of files:
read na
while [  $N -le $na ]
do
echo Enter file name:
read fn
cp $fn $nn
N=`expr $N + 1`
done
