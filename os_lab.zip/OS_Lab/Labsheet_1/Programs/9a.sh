echo "Enter  vector1 coordinates"

read a1
read b1
read c1

echo "Enter vector2 coordinates"
read a2
read b2
read c2
echo " Scalar product"
echo "($a1 * $a2) + ($b1 * $b2) + ($c1 * $c2)" | bc


