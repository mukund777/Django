#!/bin/bash
echo "Enter the file name: "
read file
echo "Enter the word to search: "
read word
grep $word $file