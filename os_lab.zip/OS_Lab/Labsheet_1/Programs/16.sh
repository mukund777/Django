#!/bin/bash
echo "Enter the operation :"
echo "a. Currently logged user and his long name
b. Current shell
c. Home directory
d. Operating system type
e. Current path setting
f. Current working directory
g. All available shells"
read operation
if [ $operation = -a ]
then
who
elif [ $operation = -b ]
then
echo $SHELL
elif [ $operation = -c ]
then
ls ~
elif [ $operation = -d ]
then
uname -a
elif [ $operation = -e ]
then
ls -lS
elif [ $operation = -f ]
then
pwd
elif [ $operation = -g ]
then
cat /etc/shells
fi