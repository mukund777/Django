#!/bin/bash
wc $1