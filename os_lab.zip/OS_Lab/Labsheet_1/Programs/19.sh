#!/bin/bash
read -p "Enter choices to convert:"c" for capital & "s" for small:" opt
for x in `ls`
do
	if [ ! -f $x ]
	then
		continue
	fi
	if [ $opt == 's' ]
	then
		lc=`echo $x | tr '[A-Z]' '[a-z]'`
		if [ $lc != $x ]
		then
			mv $x $lc
		fi
	elif [ $opt == 'c' ]
	then
		lc=`echo $x | tr '[a-z]' '[A-Z]'`
		if [ $lc != $x ]
		then
			mv $x $lc
		fi
	fi
done
