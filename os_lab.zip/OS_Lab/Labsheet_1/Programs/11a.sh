#!/bin/bash
echo "Enter the file name: "
read file
wc $file