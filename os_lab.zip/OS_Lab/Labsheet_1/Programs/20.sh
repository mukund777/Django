#!/bin/bash
read -p "Enter a file name :" name
fgrep -o ' ' $name | wc -l

