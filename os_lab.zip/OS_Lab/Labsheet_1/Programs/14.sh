#!/bin/bash
echo "Enter the 1st file name: "
read file1
echo "Enter the 2nd file name: "
read file2
cat $file1 $file2 > out.txt 