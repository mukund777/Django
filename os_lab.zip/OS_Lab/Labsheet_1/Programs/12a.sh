#!/bin/bash
echo "Enter the directory :"
read file
ls $file
	
