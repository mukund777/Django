#!/bin/sh
echo "Enter first variable:"
read first
echo "Enter second variable:"
read second
echo "Enter a operation"
echo "Add -a Subtract-s Multiply -m Quotient -c Remainder -r"
read operation
if [ $operation = -a ]
then
echo "$first + $second" | bc -l
elif [ $operation = -s ]
then
echo "$first - $second" | bc -l
elif [ $operation = -m ]
then
echo "$first * $second" | bc -l
elif [ $operation = -c ]
then
echo "$first / $second" | bc -l
elif [ $operation = -r ]
then
echo "$first % $second" | bc -l
fi
