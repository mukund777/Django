#!/bin/bash
ls $1