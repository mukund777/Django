#!/bin/sh
first=$1
second=$2
operation=$3
if [ $operation = -a ]
then
echo "$first + $second" | bc -l
elif [ $operation = -s ]
then
echo "$first - $second" | bc -l
elif [ $operation = -m ]
then
echo "$first * $second" | bc -l
elif [ $operation = -c ]
then
echo "$first / $second" | bc -l
elif [ $operation = -r ]
then
echo "$first % $second" | bc -l
fi

