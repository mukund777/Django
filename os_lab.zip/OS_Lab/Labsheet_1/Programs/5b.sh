#!/bin/bash
N=$1 
i=2
f=0
while test $i -le `expr $N / 2`  
do
if test `expr $N % $i` -eq 0  
then
f=1 
fi
i=`expr $i + 1` 
done
if test $f -eq 1  
then
echo "Not Prime"
else
echo "Prime"
fi