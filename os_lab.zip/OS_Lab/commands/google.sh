#!/bin/bash
google-chrome "https://www.google.com/search?q=$@"
