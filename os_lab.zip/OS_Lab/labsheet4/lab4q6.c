#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <limits.h>
#include <string.h>

#define READEND 0
#define WRITEEND 1

int main()
{
	int fp1[2];
	int fp2[2];
	int sum,n;
	int buffer[1024];
	if(pipe(fp1) ==-1)
	{
		printf("Pipe1 Failed");
		return 0;
	}
	if(pipe(fp2)==-1)
	{
		printf("Pipe2 Failed");
		return 0;
	}
	printf("Parent Process \n");
	printf("Enter numbers until, a special character is entered: \n");
	int i=0;
	while(1)
	{
		char temp[10];
		scanf("%s",&temp);
		if(isdigit(temp[0]))
		{
			int no=atoi(temp);
			no=no*no;
			buffer[i]=no;
			i++;
		}
		else
		{
			buffer[i]=INT_MIN;
			break;
		}
	}
	write(fp1[WRITEEND],buffer,sizeof(buffer));
	write(fp2[WRITEEND],buffer,sizeof(buffer));

	pid_t pid=fork();
	if(pid==0)
	{
		int s=0,i=0;
		read(fp1[READEND],buffer,sizeof(buffer));
		while(buffer[i]!=INT_MIN)
		{
			s+=buffer[i];
			i++;
		}
		memset(buffer,0,sizeof(buffer));
		buffer[0]=s;
		write(fp1[WRITEEND],buffer,sizeof(buffer));
		close(fp1[WRITEEND]);
	}
	else
	{
		wait(NULL);
		printf("Child 1 terminated, sum calculated\n");
		read(fp1[RD],buffer,sizeof(buffer));
		sum=buffer[0];
		close(fp1[READEND]);
		pid_t pid1=fork();
		if(pid1==0)
		{
			int n=0;
			read(fp2[READEND],buffer,sizeof(buffer));
			while(buffer[n]!=INT_MIN)
				n++;
			close(fp2[READEND]);
			memset(buffer,0,sizeof(buffer));
			buffer[0]=n;
			write(fp2[WRITEEND],buffer,sizeof(buffer));
			close(fp2[WRITEEND]);
		}
		else
		{
			wait(NULL);
			printf("Child 2 terminated, n calculated\n");
			read(fp2[READEND],buffer,sizeof(buffer));
			n=buffer[0];
			float avg=(float)sum /n;
			printf("Sum : %d\n",sum);
			printf("N: %d\n",n);
			printf("Mean Square Average: %0.2f",avg);
		}
	}
	exit(0);
}
