#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <ctype.h>
#include <unistd.h>

#define BUFFERSIZE 25
#define READEND 0
#define WRITEEND 1
int main()
{
char buffer[1024];
int fd[2];
pid_t pid;

if (pipe(fd) == -1)
{
	printf("Pipe failed");
}

pid=fork();

if(pid==0)
{
	printf("Child Process\n");
	printf("Enter String: ");
	scanf("%s", &buffer);
	close(fd[READEND]);
	write(fd[WRITEEND],buffer,strlen(buffer)+1);
	close(fd[WRITEEND]);
}
else
{
	wait(NULL);
	close(fd[WRITEEND]);
	read(fd[READEND],buffer,sizeof(buffer));
	int i=0;
	while(buffer[i] !='\0')
		{
			buffer[i]=toupper(buffer[i]);
			i++;
		}
	close(fd[READEND]);
	printf("Parent Process\nFinal String: %s\n",buffer);

}
return 0;
}
